@extends('layouts.front')
@include('building.form')