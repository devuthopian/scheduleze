@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Sign Up</div>
                <div class="card-header">Signup for Scheduleze
              First We'll need to confirm your email address.</div>
        </div>
    </div>
</div>
@endsection
