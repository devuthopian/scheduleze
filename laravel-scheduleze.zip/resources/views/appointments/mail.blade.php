@if(isset($text) || !empty($text))
	{!! $text !!}
@endif
{!!  $email_body !!}