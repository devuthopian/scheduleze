<?php $__env->startSection('content'); ?>
    <div class="signup_section">
        <div class="signup_cont nsignup_cont">
            <div class="container">
            <h3>New Inspector</h3>
            <?php echo Form::open([ 'route' => ['StoreInspector'],'method' => 'post'] ); ?>

                <?php echo e(csrf_field()); ?>

                <div class="form-group has-feedback <?php echo e($errors->has('firstname') ? ' has-error ' : ''); ?>">
                <div class="col-12">
                <!-- <?php echo Form::label('firstname', trans('profile.firstname') , array('class' => 'col-12 control-label'));; ?> -->
                <?php echo Form::text('firstname',NULL, array('id' => 'firstname', 'class' => 'form-control', 'placeholder' => trans('profile.firstname'), 'required' => 'required')); ?>

                <span class="glyphicon <?php echo e($errors->has('firstname') ? ' glyphicon-asterisk ' : ' '); ?> form-control-feedback" aria-hidden="true"></span>
                <?php if($errors->has('firstname')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('firstname')); ?></strong>
                </span>
                <?php endif; ?>
                </div>

                 <div class="col-12">
                 <!-- <?php echo Form::label('lastname', trans('profile.lastname') , array('class' => 'col-12 control-label'));; ?> -->
                <?php echo Form::text('lastname',NULL, array('id' => 'lastname', 'class' => 'form-control', 'placeholder' => trans('profile.lastname'),  'required' => 'required')); ?>

                <span class="glyphicon <?php echo e($errors->has('lastname') ? ' glyphicon-asterisk ' : ' '); ?> form-control-feedback" aria-hidden="true"></span>
                <?php if($errors->has('lastname')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('lastname')); ?></strong>
                </span>
                <?php endif; ?>
                </div>


                    <div class="col-12">
               
                <?php echo Form::email('email',NULL, array('id' => 'txtemail', 'class' => 'form-control', 'placeholder' => 'Email', 'required' => 'required')); ?>

                <span class="glyphicon <?php echo e($errors->has('email') ? ' glyphicon-asterisk ' : ' '); ?> form-control-feedback" aria-hidden="true"></span>
                <?php if($errors->has('email')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
                <?php endif; ?>
                </div>


                 <div class="col-12">
                <!-- <?php echo Form::label('backupEmail', trans('profile.backupEmail') , array('class' => 'col-12 control-label'));; ?> -->
                <?php echo Form::email('backupEmail',NULL, array('id' => 'backupEmail', 'class' => 'form-control', 'placeholder' => trans('profile.backupEmail'))); ?>

                <span class="glyphicon <?php echo e($errors->has('backupEmail') ? ' glyphicon-asterisk ' : ' '); ?> form-control-feedback" aria-hidden="true"></span>
                <?php if($errors->has('backupEmail')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('backupEmail')); ?></strong>
                </span>
                <?php endif; ?>
                </div>


                 <div class="col-12">
                <!-- <?php echo Form::label('username', trans('profile.username') , array('class' => 'col-12 control-label'));; ?> -->
                <?php echo Form::text('username',NULL, array('id' => 'username', 'class' => 'form-control', 'placeholder' => trans('profile.username'),  'required' => 'required')); ?>

                <span class="glyphicon <?php echo e($errors->has('username') ? ' glyphicon-asterisk ' : ' '); ?> form-control-feedback" aria-hidden="true"></span>
                <?php if($errors->has('username')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('username')); ?></strong>
                </span>
                <?php endif; ?>
                </div>

                  <div class="col-12">
                    <input name="password" id="password" type="password" class="<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?> form-control" placeholder="Password"  autofocus>

                    <?php if($errors->has('password')): ?>
                       <span class="invalid-feedback">
                           <strong><?php echo e($errors->first('password')); ?></strong>
                       </span>
                    <?php endif; ?>
                  </div>
                   <div class="col-12">
                   <!-- Confirm Password -->
                   <input name="password_confirmation" id="password-confirm" type="password" placeholder="Confirm Password" class="form-control"  autofocus>
                   </div>
                  <div class="col-12">
                   <div class="form-group">
                        <?php echo Form::Label('Days in Advance Padding', 'Days in Advance Padding'); ?>

                        <br>
                       <span>How many days should the scheduler skip before offering your first appointment?</span>
                        <?php echo show_day_padding(); ?>

                    </div>
                    </div>
                     <div class="col-12">
                   <div class="form-group">
                        <?php echo Form::Label('Days Forward', 'Days Forward'); ?>

                        <br>
                         <span>Specify the total number of days to look forward for available appointment times.</span>
                        <?php echo show_day_forward(); ?>

                    </div>
                    </div>
                    <div class="col-12">
                   <div class="form-group">
                        <?php echo Form::Label('Trim Day List', 'Trim Day List'); ?>

                        <br>
                        <span>Throttle Schedule Openings (only show some available times after 10 days out).</span>
                        <input type="hidden" name="throttle" value="0">
                        <?php echo e(Form::checkbox('throttle',1,NULL)); ?>

                    </div>
                    </div>
                       <div class="col-12">
                   <div class="form-group">
                        <?php echo Form::Label('Inspector Masking', 'Inspector Masking'); ?>

                        <br>
                        <span>Hide this Inspector from public booking view..</span>
                        <input type="hidden" name="masking" value="0">
                        <?php echo e(Form::checkbox('masking',1,null)); ?>

                    </div>
                    </div>
                       <div class="col-12">
                   <div class="form-group">
                        <?php echo Form::Label('User Privileges', 'User Privileges'); ?>

                        <br>
                        <span>Is company administrator (can manage Inspectors for SV Inspection Service).</span>
                        <input type="hidden" name="permission" value="0">
                        <?php echo e(Form::checkbox('permission',1,NULL)); ?>

                    </div>
                    </div>
                </div>
                <div class="form-group">
                <div class="col-12 offset-sm-4">
                <?php echo Form::button(trans('profile.submitButton'),
                 array(
                    'class'             => 'btn btn-success gmailbtn',
                    'type'              => 'submit',
                )); ?>

                </div>
                </div>
                <?php echo Form::close(); ?>

                </div>
                </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>