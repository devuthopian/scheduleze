<meta charset="utf-8">
<title>Scheduleze | Customer Scheduling Solutions</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="keywords" content="Scheduleze | Customer Scheduling Solutions"/>
<meta name="body" content="Scheduleze | Customer Scheduling Solutions"/>
<meta name="description" content="Scheduleze | Customer Scheduling Solutions"/>
<meta name="summary" content="Scheduleze | Customer Scheduling Solutions"/>
<meta http-equiv="Bulletin-Text" content="Scheduleze | Customer Scheduling Solutions"/>
<meta name="page-topic" content="Scheduleze | Customer Scheduling Solutions"/>
<meta http-equiv="Content-Style-Type" content="text/css"/>
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon_icon.png')); ?>" type="image/x-icon" />
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/bootstrap.css')); ?>" rel="stylesheet">
<!-- <link href="https://unpkg.com/grapesjs/dist/css/grapes.min.css" rel="stylesheet"> -->
<!-- <link rel="stylesheet" href="<?php echo e(URL::asset('dist/grapesjs-preset-webpage.min.css')); ?>"> -->
<script src="<?php echo e(URL::asset('js/editor.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/filestack-0.1.10.js')); ?>"></script>
<!-- <script src="https://unpkg.com/grapesjs"></script> -->
<!-- <script src="<?php echo e(URL::asset('dist/grapesjs-preset-webpage.min.js')); ?>"></script> -->
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css
" rel="stylesheet"> -->

<link href="<?php echo e(asset('css/fontawesome.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/fontawesome-all.css')); ?>" rel="stylesheet">
<!-- <link href="<?php echo e(asset('css/font-awesome.min.css')); ?>" rel="stylesheet"> -->
<link href="<?php echo e(asset('css/form_builder.css')); ?>" rel="stylesheet">
<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
<!-- <link href="https://use.fontawesome.com/releases/v5.0.6/css/all.css" rel="stylesheet"> -->