<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td class="framecell" bgcolor="white">
				<div class="frame">
				<span class="head">Download PDF Inspection Report<br></span>
				<span class="subhead">Posted on $date</span><br>
				<br>
				<div class="indent">
					<img src="<?php echo e(url('images/icon_images')); ?>/<?php echo get_icon($row->pdf); ?>" border="0" align="top">
					<a href="<?php echo e(url('/viewreports/'.$id.'/'.$code.'')); ?>">
						<b>Download PDF Report Now &#187;&nbsp;</b>
					</a>
				</div>
				<?php if(strlen($row->summary) > 1): ?>
			        <br><br><span class="formlabel">Summary</span><br><?php echo e($row->summary); ?></span><br>
			    <?php endif; ?>

			    <?php if(strlen($row->memo) > 1): ?>
			        <br>
			        <span class="formlabel">
			        	Memo
			        </span>&nbsp;&nbsp;
			        <span class="note">
			        	(Only available to logged in inspectors)
			        </span><br><?php echo e($row->memo); ?></span><br>
			    <?php endif; ?>
				<br><br><br><br><br><br></div>			
			</tr>
		</table>	
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>