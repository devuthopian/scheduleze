<table width="100%" border="0" cellspacing="0" cellpadding="0">
	<tr>
		<td class="framecell" bgcolor="white">
		<div class="frame">
		<div class="head"><?php echo $business_name; ?> Receipt #<?php echo e($id); ?><br>
			<?php echo e($row->firstname); ?>, thank you for scheduling an inspection!
		</div>
		<br><br>
			<div class="right">
			<?php echo e($paypal_link); ?>

			</div>
			<?php echo $list; ?>

			<br><br><br>
		</div>

		<div class="logo">
			<img src="'. public_path() .'/images/logo.png" alt="Take command of your day" width="244" height="79" border="0">
		</div>
		<div class="frame-closing">	
		<br>Questions? Call <?php echo e($business_phone); ?> <?php if(!empty($business_email)): ?> or Email <a href="mailto:<?=$business_email?>"><?php echo e($business_email); ?> <?php endif; ?></a><br><br>
				<span class="note">Booked on <?php echo e($date_added); ?> ~ </span>
		<span class="note">Printed on <?php echo e($date_printed); ?></span>
		</div>
		</td>
	</tr>
</table>

<style type="text/css">
	.head{
		font-size: 20px;
	}
	b{
		color: #F96E0A;
	}
	.middleinfo {
		padding: 20px;
		background: #eee;
	}
</style>