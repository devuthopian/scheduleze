<div class="loader"></div>
<div class="header_section">
    <div class="head_left"> <?php if(auth()->guard()->guest()): ?><a href="<?php echo e(url('scheduling_solutions')); ?>"> <?php else: ?> <a href="#"> <?php endif; ?><img src="<?php echo e(url('images/logo.png')); ?>" alt="Take command of your day" class="logohead"></a></div>
    <div class="head_right">
        <div class="navigation">
            <?php if(auth()->guard()->guest()): ?>
                <nav>
                    <a href="#" class="n_toggle"><i class="fa fa-bars fa-2x"></i></a>
                    <ul>
                        <li><a href="<?php echo e(url('/#signup')); ?>">Scheduling Solution</a></li>
                        <li><a href="<?php echo e(url('success_stories#signup')); ?>">Success Stories</a></li>
                        <li><a href="<?php echo e(url('demo#signup')); ?>">Demo</a></li>
                        <li><a href="<?php echo e(url('/faq#signup')); ?>">FAQ</a></li>
                        <!--<li><a href="#">Support</a></li> -->
                        <li><a href="<?php echo e(url('contact#signup')); ?>">Contact</a></li>
                        <?php 
                            $strchr = substr(strrchr(url()->current(),"/"),1); 
                        ?>

                        <?php if($strchr != 'login' && $strchr != 'account_info'): ?>
                            <li class="try_it_now"><a href="#signup">Try It Now</a></li>
                            <li class="login"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php else: ?>
                <?php 
                    $hashvalue = session('hashvalue');
                    $id = Auth::user()->id;
                    $now = time();
                    $tomorrow = time() + 86400;
                    $tomorrow = get_todays_starttime($tomorrow);
                    $first = get_todays_starttime($now);
                    $getbusindus = getBusinessIndustry(session('indus_id'));
                ?>
                <nav>
                    <a href="#" class="n_toggle"><i class="fa fa-bars fa-2x"></i></a>
                    <ul>
                        <?php if(auth()->guard()->guest()): ?>
                            <li>
                                <a href="<?php echo e(url('scheduling_solutions')); ?>">Home</a>
                            </li>
                        <?php endif; ?>
                        <li class="arrowicon">
                            <a href="#">Appointments</a>
                            <ul >
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/booking/appointment')); ?>">Bookings</a>
                                </li>
                                <li>
                                    <?php if(!empty($hashvalue)): ?>
                                        <a href="<?php echo e(url('template/'.$hashvalue)); ?>">Add Appointment</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('scheduleze/appointments')); ?>">Add Appointment</a>
                                    <?php endif; ?>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/dayticket/'.$id.'/'.$first)); ?>">My Tickets</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/dayticket/'.$id)); ?>">My Today</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/dayticket/'.$id.'/'.$tomorrow)); ?>">My Tomorrow </a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/mapmyday')); ?>">Map My Day</a>
                                </li>
                            </ul>
                        </li>
                        <li class="arrowicon">
                            <a href="#">Blockouts</a>
                            <ul >
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/booking/blockouts')); ?>">Blockouts</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/scheduleze/blockout/AddBlockout')); ?>">Add Blockout</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('Reoccurrence')); ?>">Recurring</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('scheduleze/BusinessHours')); ?>">Business Hours</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(route('Document')); ?>">Document</a>
                        </li>
                        <li class="arrowicon">
                            <a href="<?php echo e(url('/form/BuildingTypes')); ?>"><?php echo e(__('nav.services')); ?></a>
                            <ul >
                                <li>
                                    <a href="<?php echo e(url('/form/BuildingTypes')); ?>"><?php echo e($getbusindus->type_label); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/form/BuildingSizes')); ?>"><?php echo e($getbusindus->size_label); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/form/BuildingAges')); ?>"><?php echo e($getbusindus->age_label); ?></a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('/form/Addons')); ?>"><?php echo e($getbusindus->addon_label); ?></a>
                                </li>
                            </ul>
                        </li>
                        <li class="arrowicon">
                            <a href="<?php echo e(route('Location')); ?>">Locations</a>
                            <ul >
                                <li>
                                    <a href="<?php echo e(route('Location')); ?>">Add/Remove Location</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('Drivetime')); ?>">Drivetimes</a>
                                </li>
                            </ul>
                        </li>
                        <li>
                            <a href="<?php echo e(route('ZigZag')); ?>">ZigZag</a>
                        </li>
                        <li class="arrowicon">
                            <a href="#">Users</a>
                            <ul >
                                <li>
                                    <a href="<?php echo e(route('Inspectors')); ?>">Inspectors</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('AddInspector')); ?>">Add Inspector</a>
                                </li>
                            </ul>
                        </li>
                        <li class="arrowicon">
                            <a href="<?php echo e(url('profile')); ?>">Profile</a>
                            <ul>
                                <li>
                                    <a href="<?php echo e(url('profile')); ?>">User Profile</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(url('business_info')); ?>">Business Profile</a>
                                </li>
                                <?php if(session('administrator') == 1): ?>
                                    <li>
                                        <a href="<?php echo e(url('services/content')); ?>">Services Content</a>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <a href="<?php echo e(url('/profile/Email/Attachment')); ?>">Email Attachment</a>
                                </li>
                                <li>
                                    <a href="#">Recurring Payment</a>
                                </li>
                                <li>
                                    <a href="<?php echo e(route('schedulepanel')); ?>"><?php echo e(__('nav.SchedulePanel')); ?></a>
                                </li>
                            </ul>
                        </li>
                        <li class="arrowicon">
                            <a href="<?php echo e(url('profile')); ?>"><?php echo e(ucfirst(Auth::user()->name)); ?></a>
                            <ul>
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Logout')); ?>

                                    </a>
                                </li>
                            </ul>
                        </li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                        <!-- <li class="nav-item dropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                        </li> -->
                    </ul>
                </nav>
            <?php endif; ?>
        </div>
    </div>
</div>


    <div class="col-sm-10">
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
    </div>
    <?php if(auth()->guard()->guest()): ?>
    <?php else: ?>
        <?php if(empty(session('business_id'))){ ?>
            <div class="col-sm-10">            
                <div class="alert alert-warning">
                    You need to fill business info before proceeding to something else. It will help us to cooperate with you! <span class="breadcrumb"> Profile > Business Profile </span>
                </div>
            </div>
        <?php } ?>
    <?php endif; ?>
