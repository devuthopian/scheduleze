<?php $__env->startSection('content'); ?>
<div class="banner_section">
    <div class="container">
        <h2>FAQ</h2> 
        <p>Here are some FAQs</p>     
    </div>
</div>
<div class="content_section">
    <div class="container">
        <div class="content_left">
            <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h3 class="faq-category"><?php echo $category->name; ?></h3>
                    <div class="body col-lg-12">
                        <div id="faq-box" class="row mt-3">
                            <div class="<?php echo e($category->slug); ?>">
                                <?php $__currentLoopData = $category->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="mb-3">
                                        <div class="card-header">
                                            <h4 class="card-title">
                                                <a data-toggle="collapse" data-parent=".<?php echo e($category->slug); ?>" href="#faq-<?php echo e($faq->id); ?>"><?php echo $faq->question; ?></a>
                                            </h4>
                                        </div>
                                        <div id="faq-<?php echo e($faq->id); ?>" class="card-collapse collapse" data-id="<?php echo e($faq->id); ?>">
                                            <div class="card-body">
                                                <?php echo $faq->answer; ?>

                                            </div>
                                            <div id="faq-footer-<?php echo e($faq->id); ?>" class="card-footer" style="border-top: 1px solid #ddd;">
                                                <div class="btn-group btn-group-sm">
                                                    <span class="btn" style="padding-left: 0px;">Was this question helpful?</span>
                                                    <a class="btn btn-success btn-helpful" href="#" data-id="<?php echo e($faq->id); ?>" data-type="helpful_yes">
                                                        <i class="fa fa-thumbs-up"></i> Yes
                                                    </a>
                                                    <a class="btn btn-danger btn-helpful" href="#" data-id="<?php echo e($faq->id); ?>" data-type="helpful_no">
                                                        <i class="fa fa-thumbs-down"></i> No
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="content_right">
            <h2>About Scheduleze</h2> 
            <ul>
                <li><a href="#">Can I use Scheduleze on my website?</a></li>
                <li><a href="#">I don't have a website, what now?</a></li>
                <li><a href="#">How much does Scheduleze cost?</a></li>
                <li><a href="#">What's included with my sign up fee?</a></li>
                <li><a href="#">Is Scheduleze expandable?</a></li>
                <li><a href="#">Sign up for Scheduleze now »</a></li>         
            </ul> 
        </div> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>