<?php $__env->startSection('content'); ?>

<?php
	$i_name = get_field('users_details', 'name', $id);
	$i_last_name = get_field('users_details', 'lastname', $id);
	if(!empty(session('business_id'))){
		$business_infomation = get_business_information(session('business_id'));
	}

	if ($first == "") {
		$first = time();
		$last = $first + 1209500;
	}
?>
<?php if(!empty($errors->first())): ?>
    <div class="row col-lg-12">
        <div class="alert alert-warning">
            <span><?php echo e($errors->first()); ?></span>
        </div>
    </div>
<?php endif; ?>
<div class="bookingmain">
	<div class="bookingcontainer">
		<form action="<?php echo e(url('/scheduleze/booking/'.$form.'')); ?>" method="post">
			<?php echo csrf_field(); ?>
			<input type="hidden" name="action" value="<?php echo e($form); ?>">
			<?php echo edit_filter($first, $id, $i_name, $last); ?>

			<?php if($form == 'appointment'): ?>
				<?php
					$inc='book'; 
					$include = 'include blockouts';
					$url = url('/scheduleze/booking/all');
				?>
				<input type="hidden" name="inc" value="book">
			<?php elseif($form == 'all'): ?>
				<?php
					$form = 'Appointments & Blockouts';
					$inc = 'all';
					$include = 'only bookings';
					$url = url('/scheduleze/booking/appointment');
				?>
				<input type="hidden" name="inc" value="all">
			<?php else: ?>
				<?php 
				$inc='block';
				$include = 'include bookings';
				$url = url('/scheduleze/booking/appointment');
				?>
				<input type="hidden" name="inc" value="block">
			<?php endif; ?>
			<input type="hidden" name="order" value="type">
		</form>
	</div>
</div>
<div class="container">
	<div class="framecell">
		<div class="frameadmin">
			<div class="clearfix"></div>
        	<div class="col-sm-12">
				<table width="100%" border="0" cellspacing="0" cellpadding="0" class="bookclass table border table-responsive table-borderd table-striped select-default">
					<tr>
						<td bgcolor="white">
							<div class="frameadmin">
								<span class="head"><?php echo e(ucfirst($form)); ?> for <?php echo e($i_name); ?> <?php echo e($i_last_name); ?><br></span>
								<div>
									Review, modify or remove your appointments
									<a href="<?php echo e(url('/scheduleze/dayticket/'.$id)); ?>" target="_blank" class="note">Print Tickets »</a>
								</div>
								<a href="<?php echo e($url); ?>" class="note"><nobr><?php echo e($include); ?></nobr></a>
								<table cellpadding="3" cellspacing="0" border="0" width="100%" class="table border table-responsive table-borderd table-striped select-default">
									<form action="#" method="post" name="FormName">
										<?php echo display_for_edit($id, $first, $last, $order='', $inc); ?>

									</form>
								</table>
								<!-- <span class="note"><a href="index.php" class="note_link">&laquo; Return to Admin Home</a></span> -->
							</div>
						</td>
					</tr>
				</table>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>