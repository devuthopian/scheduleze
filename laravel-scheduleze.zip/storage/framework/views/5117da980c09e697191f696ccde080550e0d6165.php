<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
			<h3>
				Select Inspector
			</h3>
			<div class="clearfix"></div>
			<span>
				Bold Names indicate Administrator status
			</span>
			<table border="0" cellspacing="4" cellpadding="0" class="table border table-responsive table-borderd table-striped select-default">
                <tbody>
                    <tr class="dark-table-heading">
                        <td>Inspector</td>
                        <td>
                        	<span class="formlabel">
                        		View
                        	</span>
                        </td>
                        <td>
                        	Action
                        </td>
                    </tr>
                    <?php $__currentLoopData = $userdetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                    <tr>
	                        <td>
	                        	<b>
	                        		<?php echo e($details->name); ?>

	                        	</b>
	                        </td>
	                        <td>
	                        	<a href="<?php echo e(url('/scheduleze/booking/appointment/'.$details->user_id)); ?>">
	                        		Bookings
	                        	</a> | 
	                        	<a href="<?php echo e(url('/scheduleze/booking/blockouts/'.$details->user_id)); ?>">
	                        		Blockouts
	                        	</a>
	                        </td>
	                        <td>
	                        	<a href="<?php echo e(url('/profile/'.$details->user_id)); ?>">Edit</a> <!-- / <a href="#">Remove</a> -->
	                        </td>
	                    </tr>
	                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>