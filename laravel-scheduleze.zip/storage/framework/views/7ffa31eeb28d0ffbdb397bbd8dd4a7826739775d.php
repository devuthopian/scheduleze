<link rel="stylesheet" href="<?php echo e(URL::asset('css/panelstyle.css')); ?>">
<link rel="shortcut icon" href="<?php echo e(asset('images/favicon_icon.png')); ?>" type="image/x-icon" />
<!-- <a href="<?php echo e(URL::previous()); ?>" class="gobutton">Go Back</a> -->
<hr>
<div class="takehtml">
	<div id="dontbreakdiv" class="dontbdiv">
		<div class="panel">
			<?php if(!empty($Inspector)): ?>
				<?php 
					$countInspector = count($Inspector);
					if($countInspector > 1){
						$form = 'BookingAvailable';
					}else{
						$form = 'BookingForm';
					}

				?>

			<?php endif; ?>
			<?php if(!empty($businessinfo)): ?>
			<?php echo Form::open([ 'route' => [$form],'method' => 'post', 'id' => 'txtForm'] ); ?>

				Book your inspection now with <br>
				<?php if(!empty($businessinfo)): ?>
					<?php echo e($businessinfo->name); ?> <br>
					<?php echo e($businessinfo->address); ?> <?php echo e($businessinfo->city); ?> <?php echo e($businessinfo->state); ?> <br>
					Phone: <?php echo e($businessinfo->phone); ?> ~ <?php echo e($businessinfo->public_phone); ?> <br>
				<?php endif; ?>

				<br>
				<input type="hidden" name="reference_id" value="<?php echo e($id); ?>">
				<input type="hidden" name="businessId" value="<?php echo e($businessid); ?>">
				<p class="bgtitle">Select Building Type Here</p>
				<select name="building_type" class="" required>
					<option value="">--Select--</option>
					<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($type->id); ?>" <?php if($type->selected == 1): ?> selected <?php endif; ?>><?php echo e($type->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<select name="building_size" class="">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($size->id); ?>" <?php if($size->selected == 1): ?> selected <?php endif; ?>><?php echo e($size->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<select name="building_age" class="">
					<option value="">--Select--</option>
					<?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($age->id); ?>" <?php if($age->selected == 1): ?> selected <?php endif; ?>><?php echo e($age->name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>


				<p class="subhead">Please check all boxes that apply below:</p>
				<?php $i=0; ?>
				<?php $__currentLoopData = $addons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<input type="checkbox" name="addon[<?php echo e($i); ?>]" id="<?php echo e($addon->id); ?>" value="<?php echo e($addon->id); ?>"><?php echo e($addon->name); ?> - $<?php echo e($addon->price); ?>

					<?php $i++; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<p class="subhead">Select Location<br>
										
				<select name="location" class="small_select" required>
					<option value="">--Select--</option>
					<?php $__currentLoopData = $Location; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</select>
				<input type="submit" value="Find Appointment »"></p>
			<?php echo Form::close(); ?>

			<?php endif; ?>
		</div>
	</div>
</div>
<div class="alert-info">
</div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script type="text/javascript">
	var htmlcss = '.gjs-cv-canvas{top:0;width:100%;height:100%}.panel{width:90%;max-width:700px;border-radius:3px;padding:30px 20px;margin:150px auto 0;background-color:#d983a6;box-shadow:0 3px 10px 0 rgba(0,0,0,0.25);color:rgba(255,255,255,0.75);font:caption;font-weight:100}.welcome{text-align:center;font-weight:100;margin:0}.logo{width:70px;height:70px;vertical-align:middle}.logo path{pointer-events:none;fill:none;stroke-linecap:round;stroke-width:7;stroke:#fff}.big-title{text-align:center;font-size:3.5rem;margin:15px 0}.description{text-align:justify;font-size:1rem;line-height:1.5rem}';
	$(document).ready(function() {
		<?php if(!empty($businessinfo)): ?>
			var wholehtml = $('.takehtml').html();

			$.ajax({
	            url : '<?php echo e(url("ajaxappointment")); ?>',
	            method : "POST",
	            data : {_token: '<?php echo e(csrf_token()); ?>', gjs_html: wholehtml, gjs_css: htmlcss },
	            dataType : "JSON",
	            success:function(data){
	                console.log(data.message);
	                $('.alert-info').html('<a href="<?php echo e(URL::previous()); ?>"><strong>Ok</strong></a>');
	            }
	        });
	    <?php else: ?>
	    	$('.alert-info').html('<strong>There is nothing to show you.</strong> Click  <a href="<?php echo e(url("/form/BuildingTypes")); ?>"><strong>here</strong></a> to add services.');
	    <?php endif; ?>
	});
</script>
<style type="text/css">
	<?php if(!empty($template)): ?>
		<?php echo $template->gjs_css; ?>

	<?php endif; ?>
</style>
