<?php $__env->startSection('content'); ?>

<?php
	if ($form == 'AddBlockout'){

		$do = "Adding Blockout";
		$submit_label = "Add Blockout";
		$checked = "checked";
		$message = "Check same day to disregard second month/day/year menus";
		$default_time = !empty(session('business_id')) ? ((time()) + get_timezone(session('business_id'))) : 0;
		$default_endtime = !empty($default_time) ? ($default_time + 3600) : 0;
		$id = session('id');
		session(['affected_inspector' => $id]);

	} else {
		$do = "Editing Blockout";
		$submit_label = "Edit Blockout";
		$checked = "";
		$message = "Check same day to disregard second month/day/year menus";

		$default_time = $row->starttime;
        $default_endtime = $row->endtime;
	}

	if (is_numeric(session('affected_inspector'))){
		$inspector = session('affected_inspector');
	} else {
		$inspector = session('id');
	}

	$i_name = get_field('users_details', 'name', $id);
	$i_last_name = get_field('users_details', 'lastname', $id);

	$inspector_popup = get_inspector_popup('name', session('affected_inspector'));
	$location = get_location_popup();
	$inspector_name = get_field('users_details', 'name', session('affected_inspector'));

	$start_popup = get_time_popup ($default_time, $designate="", 1, 1, 1, 1, 1, 1 ,'starttime');
	$end_popup = get_time_popup ($default_endtime, $designate="1", 1, 1, 1, 1, 1, 1, 'endtime');

	if ($first == "") {
		$first = time();
		$last = $first + 1209500;
	}

?>
<div class="nsignup_cont">
<div class="container">
	<div class="framecell">
		<div class="frameadmin adding_blockout_cont">
			<div class="clearfix"></div>
        	<div class="head_admin">
					<span class="head">
						<?php echo e($do); ?><br>
					</span><?php echo e($message); ?><br>
					<?php //echo "$filter"; ?>
					<form action="<?php echo e(url('/scheduleze/blockout/store')); ?>" method="post" name="FormName">
						<?php echo csrf_field(); ?>
						<input type="hidden" name="trigger" value="1">
						<input type="hidden" name="action" value="set_blockout">
						<input type="hidden" name="target" value="<?php if(isset($blockId)): ?><?php echo e($blockId); ?><?php endif; ?>">
						
						<div class="inspector_admin">
							<label>Inspector:&nbsp;</label>
							<?php echo $inspector_popup; ?>

						
						<div class="location_blockout">
							<label>&nbsp;Location:&nbsp;</label>
							<?php echo $location; ?>

						</div>
						<div class="start_admin">
							<label>Start:&nbsp; </label>
								<?php echo $start_popup; ?>

								<span class="same_day"><input type="checkbox" name="sameday" value="1" <?php echo e($checked); ?>>&nbsp;Same day</span>
							
						</div>
						<div class="end_admin">
							<label>End:&nbsp;</label>
							<?php echo $end_popup; ?>							
						</div>

						<div class="notes_admin">
							<label>Notes:</label>
							<textarea name="notes">
								<?php if(isset($row) && !empty($row)): ?> <?php echo e($row->notes); ?> <?php endif; ?>
							</textarea>
						</div>
						<div>								
							<input type="submit" value="<?php echo $submit_label?> &raquo;">&nbsp;&nbsp;
							<input type="checkbox" value="1" name="send_email">
							<span class="note">Send Email Notice to <?php echo $inspector_name?></span>
						</div>
					</form>
					<!-- <span class="note"><a href="index.php" class="note_link">&laquo; Return to Admin Home</a></span> -->
			</div>
		</div>
	</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>