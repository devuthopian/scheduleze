<?php if(!empty($template)): ?>
<div class="container">
	<div class="row">
		<?php echo $template->gjs_html; ?>

	</div>
</div>
	<style type="text/css">
		<?php echo $template->gjs_css; ?>

	</style>
<?php else: ?>
	<p>Nothing to show!</p>
<?php endif; ?>
<script src="<?php echo e(URL::asset('js/jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript">
	$(document).ready(function() {
		/* Act on the event */
		$("input[name*='_token']").val('<?php echo e(csrf_token()); ?>');

		<?php if(count($inspectors) > 1): ?>
			$('#txtForm').attr('action', '<?php echo e(url("/scheduleze/bookingavailable")); ?>');
		<?php else: ?>
			$('#txtForm').attr('action', '<?php echo e(url("/scheduleze/bookingform")); ?>');
		<?php endif; ?>
	});
	
</script>