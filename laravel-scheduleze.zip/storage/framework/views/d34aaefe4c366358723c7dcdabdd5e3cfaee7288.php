<script src="<?php echo e(asset('js/nav_jquery.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery.easing.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/form_builder.js')); ?>" defer></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>" defer></script>