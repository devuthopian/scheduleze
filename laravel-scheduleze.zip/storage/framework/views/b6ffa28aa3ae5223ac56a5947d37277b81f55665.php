<?php $__env->startSection('content'); ?>
<div class="banner_section">
     	<div class="container">
   			<h2>Contact Scheduleze</h2> 
	       	<p>Thanks for your interest in Scheduleze. Please contact us
at one of these cell-phone free email addresses.</p>     
     	</div>
   	</div>

   	<div class="content_section">
     	<div class="container">
      		<div class="content_left">
       			<p>General Email: <a href="mailto:info@scheduleze.com">info@scheduleze.com</a><br>
					Product Questions: <a href="mailto:sales@scheduleze.com">sales@scheduleze.com</a><br>
					Customer Support: <a href="mailto:support@scheduleze.com">support@scheduleze.com</a></p>


				<h3>Snailmail Address:</h3> 
				<p>
					Scheduleze<br>
					PO Box 670382<br>
					Chugiak, Alaska 99567
				</p>

				<h3>Sometimes you just want a 'real' person:</h3> 
				<p>
					Phone: 907.223.4958
				</p>
      		</div>    
     	</div>
   	</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>