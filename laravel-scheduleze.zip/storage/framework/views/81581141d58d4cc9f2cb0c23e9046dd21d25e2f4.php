<?php $__env->startSection('content'); ?>
<div class="load" style="display: none;"></div>
<script src="<?php echo e(URL::asset('js/jquery-3.3.1.min.js')); ?>"></script>
<script src="<?php echo e(URL::asset('js/materialize.js')); ?>"></script>
<link href="<?php echo e(asset('css/materialize.css')); ?>" rel="stylesheet">
	<?php echo Form::open([ 'route' => ['storebuild'],'method' => 'post'] ); ?>

<div class="building building_cont">
	<div class="container">
		<div class="frameadmin">
			<span class="head">
				<h1>Add-on Service Options</h1>
			</span>
			<span class="warning_red">Submit actions disabled for demo user</span><br>
			<span class="note">Order is the order the items appear in the popup menu, use radio button to set menu default.<!--<br>Cap is the total number of this class of service you wish to allow booked in a single calendar day.</span>--><p></p>
				<input type="hidden" name="txtform" value="<?php echo e($name); ?>">				
				<table border="0" cellspacing="0" cellpadding="2" class="table table-responsive table-bordered">
					<tbody>
						<tr class="dark-table-heading">
							<td>
								<span class="formlabel">Service Description</span><br>
							</td>
							<td>
								<span class="formlabel">Time Req'd</span><br>
							</td>
							<td>
								<span class="formlabel">Price($)</span><br>
							</td>
							<td>
								<span class="formlabel">Order&nbsp;</span><br>
							</td>
							<td>
								<span class="formlabel">Status</span><br>
							</td>
							<td>
								Available Users
							</td>
							<td>
								
							</td>
						</tr>
						<tbody class="txtBuildId">
							<input type="hidden" id="txtypol" value="<?php echo e($users_details); ?>">
							<?php $i=0; ?>
							<?php $__empty_1 = true; $__currentLoopData = $Building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BuildType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<tr class="trtable_<?php echo e($i); ?>">
									<td>
										<input class="form-control" type="text" name="desc[<?php echo e($i); ?>]" size="32" value="<?php echo e($BuildType->name); ?>" required>
										<input class="form-control" type="hidden" id="buildId" name="id[<?php echo e($i); ?>]" value="<?php echo e($BuildType->id); ?>">
									</td>
									<td>				
										<?php echo show_buffer($BuildType->id, $BuildType->buffer); ?>

									</td>
									<td>
										<input type="text" class="form-control" name="price[<?php echo e($i); ?>]" value="<?php echo e($BuildType->price); ?>" size="5" required>
									</td>
									<td align="center">
										<input type="text" class="form-control" name="rank[<?php echo e($i); ?>]" value="<?php echo e($BuildType->rank); ?>" size="3" required>
									</td>
									<td>
										<select name="forcecall[<?php echo e($i); ?>]" size="1" class="form-control">
											<option value="0" <?php if($BuildType->status == 0): ?> selected="" <?php endif; ?>>Book on-line</option>
											<option value="1" <?php if($BuildType->status == 1): ?> selected="" <?php endif; ?>>Require phone call</option>
										</select>
									</td>
									<td>
										<?php echo get_subs_users($i); ?>

									</td>
									<td>
										<a href='#' class='note_link' id="<?php echo e($BuildType->id); ?>" data-model="<?php echo e($name); ?>" data-id="<?php echo e($BuildType->id); ?>">Remove</a>
									</td>
								</tr>
								<script type="text/javascript">
								    jQuery(document).ready(function($) {
								        $('.my_select_<?php echo e($i); ?>').formSelect();
								        $('.my_select_<?php echo e($i); ?> option:not(:disabled)').not(':selected').prop('selected', true);

									    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

									    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {
									    	if($(this).attr('data-in') == 1){
									    		return $(this).html('<b>'+$(this).text()+'</b>');
									    	}else{
									        	return $(this).text();
									    	}
									    }).get();

									    $('input.select-dropdown').val(values.join(', '));
									    
									    $(".my_select_<?php echo e($i); ?> option").each(function()
										{
										    if($(this).attr('data-in') == 1){
										    	$(this).html('<b>'+$(this).text()+'</b>');
										    }
										});
								    });
								</script>	
								<?php $i++; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							    <tr class="trtable_0">
									<td><input class="form-control" type="text" name="desc[0]" size="32" value="" required>
									<input class="form-control" type="hidden" id="buildId" name="id[0]" value="0"></td>
									<td>				
										<?php echo show_buffer(0, 10800); ?>

									</td>
									<td>
										<input class="form-control" type="text" name="price[0]" value="" size="5" required>
									</td>
									<td align="center">
										<input class="form-control" type="text" name="rank[0]" value="" size="3" required>
									</td>
									<td>
										<select name="forcecall[0]" size="1" class="form-control">
											<!-- <option value="1" selected="">Book using size/age</option> -->
											<option value="0">Book on-line</option>
											<option value="1">Require phone call</option>
											<!-- <option value="3">Use as Label</option> -->
										</select>
									</td>
									<td>
										<?php echo get_subs_users(0); ?>

									</td>
									<td>
										<a href='#' class='note_link' id="0" data-id="">Remove</a>
									</td>
								</tr>
								<script type="text/javascript">

								    jQuery(document).ready(function($) {

								        $('.my_select_0').formSelect();

								        $('.my_select_0 option:not(:disabled)').not(':selected').prop('selected', true);

									    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

									    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {

									        return $(this).text();

									    }).get();

									    $('input.select-dropdown').val(values.join(', '));

									    $(".my_select_0 option").each(function()
										{
										    if($(this).attr('data-in') == 1){
										    	$(this).html('<b>'+$(this).text()+'</b>');
										    }
										});


								    });

								</script>
							<?php endif; ?>
						</tbody>
						<span id="showtxt"></span>
						<tr>
							<td colspan="8"><input type="submit" name="submit" value="Save Addon" class="submit btn btn-success bluebtn">
								<input type="hidden" name="action" value="building_types">
								<input type="hidden" name="trigger" value="2">&nbsp;&nbsp;
							</td>
						</tr>
						<tr>
							<a href="#" class="add_column columnaddons" id="add_column">Add Column</a>
						</tr>
					</tbody>
				</table>
			</span>
		</div>
		<div class="tip">
			<span class="subhead">
				Add-on Services<br>
			</span>
			Use this page to create a list of services which clients may wish to choose <b>in addition</b> to services they choose from the primary Building Type menu created on the Building Type page.  Do not use this list for services which are standalone, or independent of other services you offer.  Stand alone services belong in <a href="#" class="note">Building Type popup.</a><br><br><br><br>
		</div>
	</div>
</div>
	<script type="text/javascript">
		jQuery(document).ready(function($) {

			$('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

	        <?php $__currentLoopData = $exception; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $excep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	        	$('.my_select_<?php echo e($excep->exception); ?> option[value="<?php echo e($excep->user_id); ?>"]').prop('selected', false);
	        	$('.my_select_<?php echo e($excep->exception); ?>').formSelect();
	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


	        $('.add_column').click(function(event) {
	        	setTimeout(function(){
		        	var newcolid = $('.newcol:last').attr('data-main-id');
		        	$('.my_select_'+newcolid).formSelect();

		        	$('.my_select_'+newcolid+' option:not(:disabled)').not(':selected').prop('selected', true);

				    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

				    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {

				        return $(this).text();

				    }).get();

				    $('input.select-dropdown').val(values.join(', '));

		        	$(".my_select_"+newcolid+" option").each(function()
					{
					    if($(this).attr('data-in') == 1){
					    	$(this).html('<b>'+$(this).text()+'</b>');
					    }
					});
		        }, 500);
	        });

			$('.selectedbs').change(function() {
				var exception = $(this).attr('data-main-id');
				var user_id = [];
		        $.each($(".my_select_"+exception+" option:not(:selected)"), function(){     
		            user_id.push($(this).val());
		        });

		        var user_id = user_id.filter(function(v){return v!==''});
				var type = '<?php echo e($name); ?>';

				$.ajax({
	                url : '<?php echo e(url("/storeException")); ?>',
	                method : "POST",
	                async: false,
	                data : {user_id: user_id, _token: $('meta[name="csrf-token"]').attr('content'), exception: exception, type: type},
	                dataType : "JSON",
	                success:function(data){
	                	if(data.success == 'true'){
	                    	//alert('Saved successfully');
	                	}
	                },
	                error: function(XMLHttpRequest, textStatus, errorThrown) { 
				        alert("Status: " + textStatus); alert("Error: " + errorThrown); 
				    }
	            });
			});

		});
	</script>
	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>