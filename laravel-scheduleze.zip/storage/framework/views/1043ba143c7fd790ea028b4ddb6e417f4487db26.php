<?php $__env->startSection('content'); ?>

<div class="load" style="display: none;"></div>
<script src="<?php echo e(URL::asset('js/jquery-3.3.1.min.js')); ?>"></script>

<script src="<?php echo e(URL::asset('js/materialize.js')); ?>"></script>

<link href="<?php echo e(asset('css/materialize.css')); ?>" rel="stylesheet">

	<?php echo Form::open([ 'route' => ['storebuild'],'method' => 'post'] ); ?>


<div class="building building_cont">

	<div class="container">

		<div class="frameadmin">

			<span class="head">

                <?php if($name == 'BuildingSizes'): ?>

                    <h1>Setting Building Sizes</h1>

                <?php elseif($name == 'BuildingTypes'): ?>

                    <h1>Setting Building Types and Prices</h1>

                <?php else: ?>

                    <h1>Setting Building Ages</h1>

                <?php endif; ?>

				

			</span>

			<span class="note">Order is the order the items appear in the popup menu, use radio button to set menu default.<!--<br>Cap is the total number of this class of service you wish to allow booked in a single calendar day.</span>--><p></p>

				<input type="hidden" name="txtform" value="<?php echo e($name); ?>">

				<table border="0" cellspacing="0" cellpadding="2" class="table table-responsive table-bordered">

					<tbody>

						<tr class="dark-table-heading">

							<td>

								<span class="formlabel">Description</span><br>

							</td>

							<td>

                                <?php if($name == 'BuildingAges' || $name == 'BuildingSizes'  ): ?>

								    <span class="formlabel">Add'l Time</span><br>

                                <?php else: ?>

                                    <span class="formlabel">Time Req'd</span><br>

                                <?php endif; ?>

							</td>

							<td>

								<span class="formlabel">Price($)</span><br>

							</td>

							<td>

								<span class="formlabel">Order&nbsp;</span><br>

							</td>

                            <td>

                            </td>

							<td>

								<span class="formlabel">Status</span><br>

							</td>

							<td>

								Available Users

							</td>

							<td>



							</td>

						</tr>

						<tbody class="txtBuildId">

							<input type="hidden" id="txtypol" value="<?php echo e($users_details); ?>">

							<?php 

								$i=0;

							?>							

							<?php $__empty_1 = true; $__currentLoopData = $Building; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $BuildType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

								<tr class="trtable_<?php echo e($i); ?>">

									<td>

										<input class="form-control" type="text" name="desc[<?php echo e($i); ?>]" size="32" value="<?php echo e($BuildType->name); ?>" required>

										<input type="hidden" class="form-control" id="buildId" name="id[<?php echo e($i); ?>]" value="<?php echo e($BuildType->id); ?>">

									</td>

									<td>				

										<?php echo show_buffer($i, $BuildType->buffer); ?>


									</td>

									<td>

										<input type="text" class="form-control" name="price[<?php echo e($i); ?>]" value="<?php echo e($BuildType->price); ?>" size="5" required>

									</td>

									<td align="center">

										<input type="text" class="form-control" name="rank[<?php echo e($i); ?>]" value="<?php echo e($BuildType->rank); ?>" size="3" required>

                                    </td>

                                    <td>

										<input type="radio" value="<?php echo e($BuildType->id); ?>" name="selected[0]" <?php if($BuildType->selected == 1): ?> checked <?php endif; ?>>

									</td>

									<td>

										<select name="forcecall[<?php echo e($i); ?>]" class="form-control" size="1">

											<option value="1" <?php if($BuildType->status == 1): ?> selected="" <?php endif; ?>>Book using size/age</option>

											<option value="2" <?php if($BuildType->status == 2): ?> selected="" <?php endif; ?>>Book as standalone</option>

											<option value="0" <?php if($BuildType->status == 0): ?> selected="" <?php endif; ?>>Require phone call</option>

											<option value="3" <?php if($BuildType->status == 3): ?> selected="" <?php endif; ?>>Use as Label</option>

										</select>

									</td>

									<td>

										<?php echo get_subs_users($i); ?>


									</td>

									<td>

										<a href='#' class='note_link' id="<?php echo e($BuildType->id); ?>" data-model="<?php echo e($name); ?>" data-id="<?php echo e($BuildType->id); ?>">Remove</a>

									</td>

								</tr>

								<script type="text/javascript">

								    jQuery(document).ready(function($) {

								        $('.my_select_<?php echo e($i); ?>').formSelect();

								        $('.my_select_<?php echo e($i); ?> option:not(:disabled)').not(':selected').prop('selected', true);

									    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

									    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {

									        return $(this).text();

									    }).get();

									    $('input.select-dropdown').val(values.join(', '));
										

								        $(".my_select_<?php echo e($i); ?> option").each(function()
										{
										    if($(this).attr('data-in') == 1){
										    	$(this).html('<b>'+$(this).text()+'</b>');
										    	var getadmin = $(this).text();

										    	/*if($('.dropdown-content.multiple-select-dropdown span').not(':disabled').text() == getadmin){
										    		$('.dropdown-content.multiple-select-dropdown span').not(':disabled').html('<b>'+$(this).text()+'</b>');
										    	}*/
										    }
										});

								    });

								</script>						

								<?php $i++; ?>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

							    <tr class="trtable_0">

									<td><input class="form-control" type="text" name="desc[0]" size="32" value="" required>

									<input class="form-control" type="hidden" id="buildId" name="id[0]" value="0"></td>

									<td>				

										<?php echo show_buffer(0, 10800); ?>


									</td>

									<td>

										<input class="form-control" type="text" name="price[0]" value="" size="5" required>

									</td>

									<td align="center">

										<input class="form-control" type="text" name="rank[0]" value="" size="3" required>

									</td>

                                    <td>

                                        <input  type="radio" value="0" name="selected[0]">

                                    </td>

									<td>

										<select class="form-control" name="forcecall[0]" size="1">

											<option value="1" selected="">Book using size/age</option>

											<option value="2">Book as standalone</option>

											<option value="0">Require phone call</option>

											<option value="3">Use as Label</option>

										</select>

									</td>

									<td>

										<?php echo get_subs_users(0); ?>


									</td>

									<td>

										<a href='#' class='note_link' id="0" data-id="">Remove</a>

									</td>

								</tr>

								<script type="text/javascript">

								    jQuery(document).ready(function($) {

								        $('.my_select_0').formSelect();

								        $('.my_select_0 option:not(:disabled)').not(':selected').prop('selected', true);

									    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

									    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {

									        return $(this).text();

									    }).get();

									    $('input.select-dropdown').val(values.join(', '));

									    $(".my_select_0 option").each(function()
										{
										    if($(this).attr('data-in') == 1){
										    	$(this).html('<b>'+$(this).text()+'</b>');
										    }
										});

								    });

								</script>

							<?php endif; ?>

						</tbody>

						<span id="showtxt"></span>

						<tr>

							<td colspan="8"><input type="submit" name="submit" value="Save Building Types" class="submit btn btn-success bluebtn">

								<input type="hidden" name="action" value="building_types">

								<input type="hidden" name="trigger" value="2">&nbsp;&nbsp;

							</td>

						</tr>

						<tr>

							<a href="#" class="add_column" id="add_column">Add Column</a>

						</tr>

					</tbody>

				</table>

			</span>

		</div>

		<div class="tip">

			

				<?php if($name == 'BuildingSizes'): ?>
					<span class="subhead">
						Building Sizes Strategy
					</span>

					The fewer ranges here the better. Simpler forms encourage people to complete them. Provide additional costs and additional time required for each range or "0" if there is no additional impacts for that Building Size over your primary service cost/time which you established in your Building Types menu.

                <?php elseif($name == 'BuildingTypes'): ?>
					<span class="subhead">
						Building Types and Prices Strategy
					</span>

					You must have a Building Types menu with at least one type of service, time and cost for Scheduleze to function properly.  Building Size popups and Building Age popups are optional, and can be configured to add additional time and cost to the basic Building Type selected by the client.<br><br>If you are not going to use price modifiers, you may wish to list various service combinations here and provide total prices for each.  This creates the simplest user interface for your clients and increases the likelihood of the client to book immediately on-line (simple forms look easier to complete).<br><br>However, if you are going to setup Building Age and Building Size popups as well, use this menu for basic Building Type only.  Provide the absolute minimum price and time for each service type as the modifier popups will add additional time and costs that you specify to this baseline cost for each Building Type.<br><br>

                <?php else: ?>
					<span class="subhead">
						Building Ages Strategy
					</span>

					The simpler you make users' booking experience, the more bookings you will receive. In general, a few range selections work better than many specific choices.

					Provide additional costs and additional time required for each range or "0" if there is no additional impacts for that option over your baseline cost/time which you established in your Building Types menu.

                <?php endif; ?>

		</div>

	</div>

</div>

	<script type="text/javascript">

		jQuery(document).ready(function($) {



			$('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');



	        <?php $__currentLoopData = $exception; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $excep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	        	$('.my_select_<?php echo e($excep->exception); ?> option[value="<?php echo e($excep->user_id); ?>"]').prop('selected', false);

	        	$('.my_select_<?php echo e($excep->exception); ?>').formSelect();

	        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



	        $('.add_column').click(function(event) {
	        	setTimeout(function(){
		        	var newcolid = $('.newcol:last').attr('data-main-id');
		        	$('.my_select_'+newcolid).formSelect();

		        	$('.my_select_'+newcolid+' option:not(:disabled)').not(':selected').prop('selected', true);

				    $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:not(:checked)').not(':disabled').prop('checked', 'checked');

				    var values = $('.dropdown-content.multiple-select-dropdown input[type="checkbox"]:checked').not(':disabled').parent().map(function() {

				        return $(this).text();

				    }).get();

				    $('input.select-dropdown').val(values.join(', '));

		        	$(".my_select_"+newcolid+" option").each(function()
					{
					    if($(this).attr('data-in') == 1){
					    	$(this).html('<b>'+$(this).text()+'</b>');
					    }
					});
		        }, 500);
	        });

			$('.selectedbs').change(function() {

				var exception = $(this).attr('data-main-id');

				var user_id = [];

		        $.each($(".my_select_"+exception+" option:not(:selected)"), function(){     

		            user_id.push($(this).val());

		        });



		        var user_id = user_id.filter(function(v){return v!==''});

				var type = '<?php echo e($name); ?>';



				$.ajax({

	                url : '<?php echo e(url("/storeException")); ?>',

	                method : "POST",

	                async: false,

	                data : {user_id: user_id, _token: $('meta[name="csrf-token"]').attr('content'), exception: exception, type: type},

	                dataType : "JSON",

	                success:function(data){

	                	if(data.success == 'true'){

	                    	//alert('Saved successfully');

	                	}

	                },

	                error: function(XMLHttpRequest, textStatus, errorThrown) { 

				        alert("Status: " + textStatus); alert("Error: " + errorThrown); 

				    }

	            });

			});



		});

	</script>

	<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>