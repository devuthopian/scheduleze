<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="framecell">
        <div class="frameadmin">
            <form action="#" method="post" style=" margin-top:120px;">
            	<div class="col-sm-4">
	                <span class="head">Business hours for <?php echo e(Auth::user()->name); ?></span>
	                <br> Please specify any business hours for
	            </div>
	            <div class="col-sm-4 adminsubmitbar">
	            	<div class="form-group">
		                <select name="inspector" class="smallselect form-control">
		                    <option value="60" selected=""><?php echo e(Auth::user()->name); ?></option>
		                </select>

		                <input type="submit" name="Submit" class="submit btn btn-default" value="Switch">
		                <input type="hidden" name="action" value="business_hours" class="form-control">
		            </div>
	            </div>
            </form>
            <div class="clearfix"></div>
            <div class="col-sm-12">
	            <form action="<?php echo e(route('StoreBusinessHours')); ?>" method="post">
	            	<?php echo csrf_field(); ?>
	                Please select your normal working hours for each day
	                <br><span class="note">Specify reoccurring blockouts, like the second Tuesday of each month on your <a href="#" class="note_link">Reoccurring Blockouts</a> page.</span>
	                <br>
		                <input type="hidden" name="trigger" value="1">
		                <input type="hidden" name="action" value="business_hours">
	                <br>
	                <table border="0" cellspacing="4" cellpadding="0" class="table border table-responsive table-borderd table-striped select-default">
	                    <tbody>
	                        <tr class="dark-table-heading">
	                            <td>&nbsp;</td>
	                            <td><span class="formlabel">Open</span></td>
	                            <td><span class="formlabel">Close</span></td>
	                            <td>&nbsp;</td>
	                        </tr>
	                            <?php $__empty_1 = true; $__currentLoopData = $businesshours; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hours): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	                                <?php
	                                    if ($hours['endtime']==000) {
	                                        $start=1200;
	                                        $ams="AM";
	                                        $end=1200;
	                                        $ame="AM";
	                                        $ch="checked";
	                                    } else {
	                                        $ch= '';
	                                        /***display format code***/
	                                        if ($hours['starttime']==0) {
	                                            $start=1200;
	                                            $ams="AM";
	                                        } elseif ($hours['starttime']==1200) {
	                                            $start=1200;
	                                            $ams="PM";
	                                        } elseif ($hours['starttime']>1159) {
	                                            $ams="PM";
	                                            $start = $hours['starttime']-1200;                                            
	                                        } else {
	                                            $ams="AM";
	                                            $start = $hours['starttime'];
	                                        }
	                                        
	                                        if ($hours['endtime']==2359) {
	                                            $end=1200;
	                                            $ame="AM";
	                                        } elseif ($hours['endtime']==1200) {
	                                            $end=1200;
	                                            $ame="PM";
	                                        } elseif ($hours['endtime']<1200) {
	                                            $ame="AM";
	                                            $end = $hours['endtime'];
	                                        } else {
	                                            $ame="PM";
	                                            $end = $hours['endtime']-1200;
	                                        }
	                                        /***end display format***/
	                                    }

	                                    // get the minutes
	                                    $minute_start = substr($start, -2);
	                                    $minute_end = substr($end, -2);
	                                    
	                                    //ditch the extra zeros
	                                    $start = substr($start,0,-2);
	                                    $end = substr($end,0,-2);
	                                    
	                                    if ($start == "00"){
	                                        $start = 12;
	                                        $ams = "AM";
	                                    }
	                                    
	                                    if ($end == "00"){
	                                        $end = 12;
	                                        $ame = "AM";
	                                    }

	                                    
	                                ?>
	                                <tr>
	                                    <td><?php echo get_day_name($key); ?></td>
	                                    <td><?php echo hour_popup($start, $key, 'open').''.minute_popup($minute_start, $key, 'open').''.am_popup($ams, $key, 'open'); ?></td>
	                                    <td><?php echo hour_popup($end, $key, 'close').''.minute_popup($minute_end, $key, 'close').''.am_popup($ame, $key, 'close'); ?></td>
	                                    <td class="text-right"><input type="checkbox" name="closed[<?php echo e($key); ?>]" <?php echo e($ch); ?>>Close All day</td>
	                                </tr>
	                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
		                            <?php for($i=0;$i<7;$i++): ?>
		                                <tr>
		                                    <td><?php echo get_day_name($i); ?></td>
		                                    <td><?php echo hour_popup('',$i, 'open').''.minute_popup('',$i, 'open').''.am_popup('',$i, 'open'); ?></td>
		                                    <td><?php echo hour_popup('',$i, 'close').''.minute_popup('',$i, 'close').''.am_popup('',$i, 'close'); ?></td>
		                                    <td class="text-right"><input type="checkbox" name="closed[<?php echo e($i); ?>]">Close All day</td>
		                                </tr>
		                            <?php endfor; ?>
	                            <?php endif; ?>
	                        </tr>
	                    </tbody>
	                </table>
	                <br>
	                <input type="submit" class="submit btn btn-primary" name="Submit" value="Update Business Hours">
	            </form>
        	</div>
            <br>
            <br>
            <br>
        </div>
    </div>
    <div class="col-sm-12 align-center take-command">
	    <div class="logo">
	        <a href="index.php" class="btn btn-primary">
	        	<img src="/images/scheduleze-logo.gif" alt="Take command of your day" border="0">
	        </a>
	    </div>
	</div>
 
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>