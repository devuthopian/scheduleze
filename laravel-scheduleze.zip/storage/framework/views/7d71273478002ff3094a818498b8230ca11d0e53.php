<?php if(auth()->guard()->guest()): ?>
    <div class="footer_section">
<?php else: ?>
    <div class="footer_section loguser">
<?php endif; ?>
    <div class="container">
        <!-- <div class="footer_top">
            <div class="footer_top_cont">
                <img src="<?php echo e(url('images/footer_icon1.png')); ?>" alt="">
                <p>Snailmail Address:<br>
                    Scheduleze ,PO Box 670382<br>
                    Chugiak, Alaska 99567
                </p>
            </div>
            <div class="footer_top_cont">
                <img src="<?php echo e(url('images/footer_icon1.png')); ?>" alt="">
                <p>Sometimes you just want a <br>'real' person::<br> 907.223.4958  </p>
            </div>
            <div class="footer_top_cont">
                <img src="<?php echo e(url('images/footer_icon1.png')); ?>" alt="">
                <p>Email:<br> General Email:<br> info@scheduleze.com </p>
            </div>
        </div> -->
        <?php if(auth()->guard()->guest()): ?>
            <div class="footer_bottom">
                
                    <div class="col-sm-4">
                        <h3>Contact <br> Scheduleze</h3>
                        <p>Thanks for your interest in Scheduleze. Please contact us<br>
                            at one of these cell-phone free email addresses.
                        </p>
                    </div>
                
                <div class="col-sm-4">
                    <div class="quick_links">
                        <h3>Quick <br> Links</h3>
                        <ul>
                            <li><a href="<?php echo e(url('/')); ?>">Scheduling Solutions</a></li>
                            <li><a href="<?php echo e(url('success_stories')); ?>">Success  Stories</a></li>
                            <li><a href="<?php echo e(url('demo')); ?>">Video</a></li>
                            <li><a href="<?php echo e(url('scheduling_faq')); ?>">FAQ</a></li>
                            <li><a href="<?php echo e(url('contact')); ?>">Contact</a></li>
                            <li><a href="<?php echo e(route('login')); ?>">Client Login</a></li>
                        </ul>
                    </div>
                </div>
                <?php 
                    $strchr = substr(strrchr(url()->current(),"/"),1); 
                ?>

                <?php if($strchr != 'login' && $strchr != 'account_info'): ?>
                    <div class="col-sm-4" id="signup">
                        <h3>Try it now free for <br>30 days</h3>
                        <?php $allindustries = getallIndustries() ?>
                        <form method="POST" action="<?php echo e(route('register')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                            <?php echo csrf_field(); ?>
                            <select name="txtIndustries" required>
                                <option value="-1">Select Industrial</option>
                                <?php $__currentLoopData = $allindustries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $industries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option  value="<?php echo e($key); ?>"><?php echo e($industries); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input id="email" type="email" class="<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" placeholder="Business Email" required>
                            <!-- <input type="text" placeholder="Business Email"> -->
                            <input type="submit" value="TRY IT NOW" name="">
                        </form>
                    </div>
                <?php endif; ?>
                
            </div>
        <?php endif; ?>
    </div>
    <div class="copyright_section">
        <div class="container">
            <div class="copright_left">&copy; copyright all rights reserved</div>
            <div class="copright_right" bgcolor="#dfa427">
                <a href="mailto:support@scheduleze.com" class="bottom">support@scheduleze.com</a>
            </div>
        </div>
    </div>
</div>