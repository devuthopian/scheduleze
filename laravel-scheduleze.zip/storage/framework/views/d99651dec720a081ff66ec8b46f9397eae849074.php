<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="framecell">
		<div class="frameadmin adding_blockout_cont">
			<div class="clearfix"></div>
			<div class="head_admin">
				<?php if(Session::has('confirmstatus')): ?>
					<h1>Email Confirmation</h1>
			        <div class="alert alert-success">
			            <a class="close" data-dismiss="alert">×</a>
			            <strong><?php echo Session::get('confirmstatus'); ?></strong> 
			        </div>
			    <?php endif; ?>				
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>